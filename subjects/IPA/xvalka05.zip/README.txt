#####################################################################
#                                                                   #
#      Pro rychle otestovani zavislosti letu kulky                  #
#      na hmotnosti nebo na pocatecni rychlosti je                  #
#      mozne menit tyto hodnoty v prubehu hry pres klavesnici.      #
#                                                                   #
#####################################################################
_____________________________________________________________________

Klavesi 1,2,3 jsou prednastavene ruzne typy strel 
(ruzne hmotnosti a rychlosti)

Klavesa 1 = Lehke kulky a k nim optimalni pocatecni rychlost
Klavesa 2 = Tezke kulky a se stejnou rychlosti jako meli lehke kulky
Klavesa 3 = Extra tezke kulky a s extra velkou pocatecni rychlosti
_____________________________________________________________________

Klavesy q,e,r,f umoznuji menit aktualne nastavene hodnoty
po prednastavenych velikostech kroku.

Klavesa Q = Snizeni pocatecni rychlosti
Klavesa E = Zviseni pocatecni rychlosti
Klavesa R = Zviseni hmotnosti
Klavesa F = Snizeni hmotnosti
_____________________________________________________________________