/*
*Student login:
*/
#include <cstdio>

#ifdef DLLDIR_EX
#define DLLDIR  __declspec(dllexport) 
#else
#define DLLDIR  __declspec(dllimport) 
#endif 

#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <SDL.h>
#include <SDL_image.h>

extern "C" DLLDIR void  printcube()
	{

		glBegin(GL_QUADS);                // Begin drawing the color cube with 6 quads
										  // Top face (y = 1.0f)
										  // Define vertices in counter-clockwise (CCW) order with normal pointing out
		glColor3f(0.0f, 1.0f, 0.0f);     // Green
		glVertex3f(1.0f, 1.0f, -1.0f);
		glVertex3f(-1.0f, 1.0f, -1.0f);
		glVertex3f(-1.0f, 1.0f, 1.0f);
		glVertex3f(1.0f, 1.0f, 1.0f);

		// Bottom face (y = -1.0f)
		glColor3f(1.0f, 0.5f, 0.0f);     // Orange
		glVertex3f(1.0f, -1.0f, 1.0f);
		glVertex3f(-1.0f, -1.0f, 1.0f);
		glVertex3f(-1.0f, -1.0f, -1.0f);
		glVertex3f(1.0f, -1.0f, -1.0f);

		// Front face  (z = 1.0f)
		glColor3f(1.0f, 0.0f, 0.0f);     // Red
		glVertex3f(1.0f, 1.0f, 1.0f);
		glVertex3f(-1.0f, 1.0f, 1.0f);
		glVertex3f(-1.0f, -1.0f, 1.0f);
		glVertex3f(1.0f, -1.0f, 1.0f);

		// Back face (z = -1.0f)
		glColor3f(1.0f, 1.0f, 0.0f);     // Yellow
		glVertex3f(1.0f, -1.0f, -1.0f);
		glVertex3f(-1.0f, -1.0f, -1.0f);
		glVertex3f(-1.0f, 1.0f, -1.0f);
		glVertex3f(1.0f, 1.0f, -1.0f);

		// Left face (x = -1.0f)
		glColor3f(0.0f, 0.0f, 1.0f);     // Blue
		glVertex3f(-1.0f, 1.0f, 1.0f);
		glVertex3f(-1.0f, 1.0f, -1.0f);
		glVertex3f(-1.0f, -1.0f, -1.0f);
		glVertex3f(-1.0f, -1.0f, 1.0f);

		// Right face (x = 1.0f)
		glColor3f(1.0f, 0.0f, 1.0f);     // Magenta
		glVertex3f(1.0f, 1.0f, -1.0f);
		glVertex3f(1.0f, 1.0f, 1.0f);
		glVertex3f(1.0f, -1.0f, 1.0f);
		glVertex3f(1.0f, -1.0f, -1.0f);
		glEnd();  // End of drawing color-cube
	}



#pragma region Need_It

#define PI 3.1415926535898
// Cosinus ve stupnich
#define Cos(th) cos(PI/180*(th))
// Sinus ve stupnich
#define Sin(th) sin(PI/180*(th))

/**
 * Funkce je pouzita pro vykreslovani kulky
 */
extern "C" DLLDIR void Vertex(float deg1, float deg2)
{
	float x = Cos(deg1)*Sin(deg2);
	float y = Cos(deg1)*Cos(deg2);
	float z = Sin(deg1);
	glVertex3f(x, y, z);
}

#define DEGREES_OF_ROTATION 5 

/**
 * Vypreslovani koule
 */
extern "C" DLLDIR void printsphere() {
	int deg1, deg2;
	
	for (deg2 = -90; deg2 < 90; deg2 += DEGREES_OF_ROTATION) {
		glBegin(GL_QUAD_STRIP);
		for (deg1 = 0; deg1 <= 360; deg1 += DEGREES_OF_ROTATION<<2) {
			glColor3f(0.5, 0.5, 0.5);
			Vertex(deg1, deg2);
			glColor3f(0.0, 0.0, 0.0); 
			Vertex(deg1, deg2 + DEGREES_OF_ROTATION);
		}
		glEnd();
	}
}
/**
* Funkce pro pomocne vykreslovani kulky
*/
extern "C" DLLDIR void printbulletgl(float x, float y, float z, float m) {
	glPushMatrix();
	glEnable(GL_COLOR_MATERIAL);
	glTranslatef(x, y, z);
	float scale = m * 300;
	glScaled(scale, scale, scale);
	//glScaled(0.3f, 0.3f, 0.3f);
	//printcube();
	printsphere();
	glPopMatrix();
}


/**
 * Funkce pro spocitani sinu a cosinu
 * @param angle Uhle pro ktery bude sinus a cosinus spocitan
 * @param sinAngle Ukazatel do ktereho se ulozi vypocteny sinus
 * @param cosAngle Ukazatel do ktereho se ulozi vypocteny cosinus
*/
extern "C" DLLDIR void SinCosAngle(float *angle, float *sinAngle, float *cosAngle) {

	*sinAngle = (float)Sin(*angle);
	*cosAngle = (float)Cos(*angle);

}

//extern double get_height(double x, double y, bool n);

extern "C" DLLDIR void abc() {
	//double x = get_height(1, 1, false);
}

#pragma endregion



#pragma region Only_tests




#pragma endregion

